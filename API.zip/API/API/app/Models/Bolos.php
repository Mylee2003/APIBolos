<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Bolos extends Model
{
    use HasFactory;
    protected $fillable =[
        'NomeBolo',
        'SaborBolo',
        'QuantidadeBolo',
        'Peso',
        'Decoracao'   
    ];
}
