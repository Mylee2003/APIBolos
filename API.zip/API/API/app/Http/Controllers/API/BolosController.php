<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Bolos;
use Illuminate\Support\Facades\Validator;

class BolosController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $dadosBolos = Bolos::All();
        $contador = $dadosBolos->count();

       return 'Bolos contados: ' . $contador . " - " . $dadosBolos;
   
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        $dadosBolos = $request ->all();
        $validador = Validator::make($dadosBolos,[
            'NomeBolo' => 'required',
            'SaborBolo' => 'required',
            'QuantidadeBolo' => 'required',
            'Peso' => 'required',
            'Decoracao' => 'required'
        ]);
        if($validador->fails()){
            return 'Registros invalidos!' .$validador ->erros(true). 500;            
        }

        $registrosBolos = Bolos::create($dadosBolos);

        if($registrosBolos){
            return 'Registros cadrastrados com sucesso'  .$registrosBolos . 201;
        }else{
            return 'Erro ao cadrastrar os registros ' . $regsitrosBolos . 500;
        }
        }

    

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
